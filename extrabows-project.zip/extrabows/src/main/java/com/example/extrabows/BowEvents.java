package com.example.extrabows;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.phys.EntityHitResult;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.ProjectileImpactEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.server.ServerStoppedEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

@EventBusSubscriber(modid = ExtraBows.MODID)
public final class BowEvents {
    /** Multi bow arrows and Trinity lasers ignore the target's invulnerability frames. */
    @SubscribeEvent
    public static void onImpact(ProjectileImpactEvent event) {
        if (!(event.getProjectile() instanceof AbstractArrow arrow) || arrow.level().isClientSide) return;

        boolean multi = ExtraBows.MULTI_RESETS_IFRAMES && arrow.getTags().contains(CustomBowItem.MULTI_TAG);
        boolean laser = ExtraBows.LASER_RESETS_IFRAMES && arrow instanceof LaserArrow;
        if (!multi && !laser) return;

        if (event.getRayTraceResult() instanceof EntityHitResult hit
                && hit.getEntity() instanceof LivingEntity target) {
            target.invulnerableTime = 0;
        }
    }

    /** Trinity Bow: spawn / remove the two floating bows. */
    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        SpiritManager.update(event.getEntity());
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        SpiritManager.remove(event.getEntity());
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        SpiritManager.clear();
    }
}
