package com.example.extrabows;

import java.util.Optional;
import java.util.UUID;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.util.RandomSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3f;

/** A purple bow that floats above the shoulder of a player who holds the Trinity Bow. */
public class SpiritBow extends Entity {
    private static final EntityDataAccessor<Optional<UUID>> OWNER =
            SynchedEntityData.defineId(SpiritBow.class, EntityDataSerializers.OPTIONAL_UUID);
    private static final DustParticleOptions GOLD =
            new DustParticleOptions(new Vector3f(1.0F, 0.82F, 0.15F), 1.0F);

    private int side = 1; // +1 = right shoulder, -1 = left shoulder (server only)
    private final float phase;

    public SpiritBow(EntityType<? extends SpiritBow> type, Level level) {
        super(type, level);
        this.noPhysics = true;
        this.phase = this.random.nextFloat() * 6.2831F;
    }

    public void setup(Player owner, int side) {
        this.entityData.set(OWNER, Optional.of(owner.getUUID()));
        this.side = side;
    }

    public int getSide() {
        return side;
    }

    @Nullable
    public Player getOwner() {
        Optional<UUID> id = this.entityData.get(OWNER);
        return id.isPresent() ? level().getPlayerByUUID(id.get()) : null;
    }

    /** Where this bow floats: above one shoulder, slightly behind. */
    public Vec3 anchor(Player owner) {
        double yaw = Math.toRadians(owner.getYRot());
        Vec3 fwd = new Vec3(-Math.sin(yaw), 0.0D, Math.cos(yaw));
        Vec3 right = new Vec3(-Math.cos(yaw), 0.0D, -Math.sin(yaw));
        double bob = Math.sin((tickCount + phase * 10.0F) * 0.12D) * 0.07D;
        return owner.position()
                .add(right.scale(side * 0.95D))
                .add(fwd.scale(-0.1D))
                .add(0.0D, owner.getBbHeight() + 0.15D + bob, 0.0D);
    }

    @Override
    public void tick() {
        super.tick();
        Player owner = getOwner();

        if (!level().isClientSide) {
            if (owner == null || !owner.isAlive() || !SpiritManager.isHoldingTrinity(owner)) {
                discard();
                return;
            }
            // glide toward the shoulder (looks like it flies out of the bow in hand)
            Vec3 np = position().lerp(anchor(owner), 0.3D);
            setPos(np.x, np.y, np.z);
            setYRot(owner.getYRot());
            setXRot(owner.getXRot());
        } else if (random.nextInt(4) == 0) {
            level().addParticle(ParticleTypes.WITCH, getX() + random.nextGaussian() * 0.25,
                    getY() + random.nextGaussian() * 0.25, getZ() + random.nextGaussian() * 0.25, 0, 0, 0);
        }
        if (level().isClientSide && owner != null && owner.isUsingItem()
                && owner.getUseItem().getItem() instanceof TrinityBowItem) {
            float progress = Math.min(1.0F, owner.getTicksUsingItem() / (float) TrinityBowItem.DRAW_TICKS);
            Vec3 f = Vec3.directionFromRotation(getXRot(), getYRot());
            TrinityBowItem.chargeParticles(level(), position().add(f.scale(0.45D)), progress);
        }
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        builder.define(OWNER, Optional.empty());
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
    }

    @Override
    public boolean isPickable() {
        return false;
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        return false;
    }
}
