package com.example.extrabows;

import java.util.List;
import java.util.Optional;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.ArrowItem;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.alchemy.PotionContents;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

@Mod(ExtraBows.MODID)
public class ExtraBows {
    public static final String MODID = "extrabows";

    /** Multi bow: reset i-frames on hit so every arrow of the volley deals full damage. */
    public static final boolean MULTI_RESETS_IFRAMES = true;
    /** Trinity lasers: same thing, all 3 beams deal full damage to one target. */
    public static final boolean LASER_RESETS_IFRAMES = true;

    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MODID);
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(Registries.ENTITY_TYPE, MODID);

    // CustomBowItem(props, drawTicks, velocityMult, arrowsPerShot, flatDamage(power), damageMult, requireFullDraw)
    // Vanilla bow: drawTicks = 20, velocityMult = 1.0, full draw damage = 6

    // Long bow: +2.5 dmg at full draw only
    public static final DeferredItem<CustomBowItem> LONG_BOW = ITEMS.register("long_bow",
            () -> new CustomBowItem(new Item.Properties().durability(400),
                    32, 1.5F, 1, power -> power >= 1.0F ? 2.5F : 0.0F, 1.0F, false));

    // Rapid bow: -2 dmg
    public static final DeferredItem<CustomBowItem> RAPID_BOW = ITEMS.register("rapid_bow",
            () -> new CustomBowItem(new Item.Properties().durability(300),
                    12, 0.4F, 1, power -> -2.0F * power, 1.0F, false));

    // Multi bow: 34 ticks (1.7s), only fires when fully drawn, 1 dmg less than a vanilla arrow,
    // and all 3 arrows together deal 1.7x one arrow (so each arrow = 1.7 / 3 of it).
    public static final DeferredItem<CustomBowItem> MULTI_BOW = ITEMS.register("multi_bow",
            () -> new CustomBowItem(new Item.Properties().durability(500),
                    34, 0.6F, 3, power -> -1.0F * power, 1.7F / 3.0F, true));

    public static final DeferredItem<TrinityBowItem> TRINITY_BOW = ITEMS.register("trinity_bow",
            () -> new TrinityBowItem(new Item.Properties().durability(500).rarity(Rarity.EPIC)));

    // Hidden item: only its 3D model is used to draw the floating bows next to a Trinity Bow user
    public static final DeferredItem<Item> SPIRIT_DISPLAY = ITEMS.register("spirit_bow_display",
            () -> new Item(new Item.Properties()));

    // Tipped-style arrow that gives Nausea (10 s)
    public static final DeferredItem<ArrowItem> NAUSEA_ARROW = ITEMS.register("nausea_arrow",
            () -> new ArrowItem(new Item.Properties().component(DataComponents.POTION_CONTENTS,
                    new PotionContents(Optional.empty(), Optional.of(0xA6C93A),
                            List.of(new MobEffectInstance(MobEffects.CONFUSION, 200))))));

    public static final DeferredHolder<EntityType<?>, EntityType<LaserArrow>> LASER_ARROW =
            ENTITIES.register("laser_arrow",
                    () -> EntityType.Builder.<LaserArrow>of(LaserArrow::new, MobCategory.MISC)
                            .sized(0.5F, 0.5F).clientTrackingRange(4).updateInterval(2)
                            .build("laser_arrow"));

    public static final DeferredHolder<EntityType<?>, EntityType<SpiritBow>> SPIRIT_BOW =
            ENTITIES.register("spirit_bow",
                    () -> EntityType.Builder.<SpiritBow>of(SpiritBow::new, MobCategory.MISC)
                            .sized(0.5F, 0.5F).noSave().fireImmune()
                            .clientTrackingRange(8).updateInterval(1)
                            .build("spirit_bow"));

    public ExtraBows(IEventBus modBus) {
        ITEMS.register(modBus);
        ENTITIES.register(modBus);
        modBus.addListener(ExtraBows::addToCreativeTab);
    }

    private static void addToCreativeTab(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.COMBAT) {
            event.accept(LONG_BOW);
            event.accept(RAPID_BOW);
            event.accept(MULTI_BOW);
            event.accept(TRINITY_BOW);
            event.accept(NAUSEA_ARROW);
        }
    }
}
