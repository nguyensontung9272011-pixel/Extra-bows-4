package com.example.extrabows;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/** Server side: keeps exactly two SpiritBow entities alive for every player holding a Trinity Bow. */
public final class SpiritManager {
    private static final Map<UUID, List<SpiritBow>> SPIRITS = new HashMap<>();

    private SpiritManager() {
    }

    public static boolean isHoldingTrinity(Player p) {
        return p.getMainHandItem().getItem() instanceof TrinityBowItem
                || p.getOffhandItem().getItem() instanceof TrinityBowItem;
    }

    public static List<SpiritBow> get(Player p) {
        List<SpiritBow> list = SPIRITS.get(p.getUUID());
        return list == null ? List.of() : list;
    }

    public static void update(Player player) {
        if (!(player.level() instanceof ServerLevel level)) return;

        List<SpiritBow> list = SPIRITS.computeIfAbsent(player.getUUID(), k -> new ArrayList<>());
        list.removeIf(s -> s.isRemoved() || s.level() != level);

        if (!player.isAlive() || player.isSpectator() || !isHoldingTrinity(player)) {
            for (SpiritBow s : list) s.discard();
            list.clear();
            return;
        }

        for (int side : new int[] {1, -1}) {
            boolean exists = false;
            for (SpiritBow s : list) if (s.getSide() == side) exists = true;
            if (exists) continue;

            // start in the hand, then glide out to the shoulder
            Vec3 look = player.getLookAngle();
            Vec3 start = player.getEyePosition().add(look.scale(0.6D)).add(0.0D, -0.3D, 0.0D);
            SpiritBow s = new SpiritBow(ExtraBows.SPIRIT_BOW.get(), level);
            s.setup(player, side);
            s.setPos(start.x, start.y, start.z);
            level.addFreshEntity(s);
            list.add(s);
        }
    }

    public static void remove(Player player) {
        List<SpiritBow> list = SPIRITS.remove(player.getUUID());
        if (list != null) for (SpiritBow s : list) s.discard();
    }

    public static void clear() {
        SPIRITS.clear();
    }
}
